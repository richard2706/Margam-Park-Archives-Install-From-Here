-- Creates the database with test data and configures readonly access for the Margam archives app.

SOURCE ./scripts/create_margam_database.sql;
SOURCE ./scripts/insert_generated_test_data.sql;
CALL CreateReadOnlyUser();
