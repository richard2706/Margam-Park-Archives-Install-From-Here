-- Creates the Margam archives database (29-01-25 version)

-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: margam_archives
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `margam_archives`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `margam_archives` /*!40100 DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci */;

USE `margam_archives`;

--
-- Table structure for table `artefact`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `artefact` (
  `identifier_group_id` varchar(3) NOT NULL,
  `identifier_number` int(11) NOT NULL,
  `identifier_key` varchar(10) GENERATED ALWAYS AS (concat(`identifier_group_id`,'-',lpad(`identifier_number`,6,'0'))) STORED,
  `file_path` varchar(1000) DEFAULT NULL,
  `date_created` datetime DEFAULT current_timestamp(),
  `date_modified` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `parent_id` varchar(50) DEFAULT NULL,
  `notes` varchar(1000) DEFAULT NULL,
  `title_en` varchar(255) DEFAULT NULL,
  `title_cy` varchar(50) DEFAULT NULL,
  `description_en` varchar(500) DEFAULT NULL,
  `description_cy` varchar(500) DEFAULT NULL,
  `category_id` varchar(2) DEFAULT NULL,
  `tags_cy` varchar(255) DEFAULT NULL,
  `culture_tag_en` varchar(255) DEFAULT NULL,
  `period_id` int(11) DEFAULT NULL,
  `creator_id` int(11) DEFAULT NULL,
  `location_coverage` varchar(255) DEFAULT NULL,
  `right_type_1` varchar(255) DEFAULT NULL,
  `right_holder_1_en` varchar(255) DEFAULT NULL,
  `right_holder_1_cy` varchar(255) DEFAULT NULL,
  `visual_artefact` tinyint(1) DEFAULT NULL,
  `general_location_id` int(11) DEFAULT NULL,
  `specific_location_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`identifier_group_id`,`identifier_number`),
  KEY `category_id` (`category_id`),
  KEY `period_id` (`period_id`),
  KEY `creator_id` (`creator_id`),
  KEY `artefact_ibfk_5` (`general_location_id`),
  KEY `artefact_ibfk_6` (`specific_location_id`),
  CONSTRAINT `artefact_ibfk_1` FOREIGN KEY (`identifier_group_id`) REFERENCES `identifier_group` (`identifier_group_id`),
  CONSTRAINT `artefact_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`category_id`),
  CONSTRAINT `artefact_ibfk_3` FOREIGN KEY (`period_id`) REFERENCES `period` (`period_id`),
  CONSTRAINT `artefact_ibfk_4` FOREIGN KEY (`creator_id`) REFERENCES `creator` (`creator_id`),
  CONSTRAINT `artefact_ibfk_5` FOREIGN KEY (`general_location_id`) REFERENCES `general_location` (`general_location_id`),
  CONSTRAINT `artefact_ibfk_6` FOREIGN KEY (`specific_location_id`) REFERENCES `specific_location` (`specific_location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Stores details about each artefact in the Margam Archives.';
/*!40101 SET character_set_client = @saved_cs_client */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER generate_identifier_number
BEFORE INSERT ON artefact
FOR EACH ROW
BEGIN
    
    SET @max_id = (SELECT COALESCE(MAX(identifier_number), 0)
                   FROM artefact
                   WHERE identifier_group_id = NEW.identifier_group_id);

    
    SET NEW.identifier_number = @max_id + 1;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = cp850 */ ;
/*!50003 SET character_set_results = cp850 */ ;
/*!50003 SET collation_connection  = cp850_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ZERO_IN_DATE,NO_ZERO_DATE,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`root`@`localhost`*/ /*!50003 TRIGGER update_identifier_number
BEFORE UPDATE ON artefact
FOR EACH ROW
BEGIN
    
    IF NEW.identifier_group_id <> OLD.identifier_group_id THEN
        
        
        SET @max_id = (SELECT COALESCE(MAX(identifier_number), 0)
                       FROM artefact
                       WHERE identifier_group_id = NEW.identifier_group_id);

        
        SET NEW.identifier_number = @max_id + 1;
    END IF;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Temporary table structure for view `artefact_details`
--

SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE VIEW `artefact_details` AS SELECT
 1 AS `identifier_group_id`,
  1 AS `identifier_number`,
  1 AS `identifier_key`,
  1 AS `identifier_group_name`,
  1 AS `file_path`,
  1 AS `date_created`,
  1 AS `date_modified`,
  1 AS `parent_id`,
  1 AS `notes`,
  1 AS `title_en`,
  1 AS `title_cy`,
  1 AS `description_en`,
  1 AS `description_cy`,
  1 AS `tags_cy`,
  1 AS `culture_tag_en`,
  1 AS `location_coverage`,
  1 AS `right_type_1`,
  1 AS `right_holder_1_en`,
  1 AS `right_holder_1_cy`,
  1 AS `visual_artefact`,
  1 AS `category_id`,
  1 AS `category_name`,
  1 AS `creator_id`,
  1 AS `creator_name`,
  1 AS `general_location_id`,
  1 AS `general_location_name`,
  1 AS `specific_location_id`,
  1 AS `specific_location_summary`,
  1 AS `period_id`,
  1 AS `period_dates` */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `category`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `category` (
  `category_id` varchar(2) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Stores the different types of artefact which an artefact can be.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `creator`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `creator` (
  `creator_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`creator_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Stores the names of the people who added archive items.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `general_location`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `general_location` (
  `general_location_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`general_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='The general location of an artefact. Corresponds to the Room/Building Stored column.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `identifier_group`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `identifier_group` (
  `identifier_group_id` varchar(3) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`identifier_group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Stores descriptions of the groups that the artefacts are categorised into. Corresponds to the first part of artefact identifier keys.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `period`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `period` (
  `period_id` int(11) NOT NULL,
  `dates` varchar(50) NOT NULL,
  PRIMARY KEY (`period_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='Stores the time periods which categorises each arefact.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `specific_location`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE IF NOT EXISTS `specific_location` (
  `specific_location_id` int(11) NOT NULL AUTO_INCREMENT,
  `summary` varchar(255) NOT NULL,
  PRIMARY KEY (`specific_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci COMMENT='The specific location of an artefact, usually corresponds to a location within a general location. Corresponds to the Location Stored column.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Current Database: `margam_archives`
--

USE `margam_archives`;

--
-- Final view structure for view `artefact_details`
--

/*!50001 DROP VIEW IF EXISTS `artefact_details`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = cp850 */;
/*!50001 SET character_set_results     = cp850 */;
/*!50001 SET collation_connection      = cp850_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `artefact_details` AS select `artefact`.`identifier_group_id` AS `identifier_group_id`,`artefact`.`identifier_number` AS `identifier_number`,`artefact`.`identifier_key` AS `identifier_key`,`identifier_group`.`name` AS `identifier_group_name`,`artefact`.`file_path` AS `file_path`,`artefact`.`date_created` AS `date_created`,`artefact`.`date_modified` AS `date_modified`,`artefact`.`parent_id` AS `parent_id`,`artefact`.`notes` AS `notes`,`artefact`.`title_en` AS `title_en`,`artefact`.`title_cy` AS `title_cy`,`artefact`.`description_en` AS `description_en`,`artefact`.`description_cy` AS `description_cy`,`artefact`.`tags_cy` AS `tags_cy`,`artefact`.`culture_tag_en` AS `culture_tag_en`,`artefact`.`location_coverage` AS `location_coverage`,`artefact`.`right_type_1` AS `right_type_1`,`artefact`.`right_holder_1_en` AS `right_holder_1_en`,`artefact`.`right_holder_1_cy` AS `right_holder_1_cy`,`artefact`.`visual_artefact` AS `visual_artefact`,`artefact`.`category_id` AS `category_id`,`category`.`name` AS `category_name`,`artefact`.`creator_id` AS `creator_id`,`creator`.`name` AS `creator_name`,`artefact`.`general_location_id` AS `general_location_id`,`general_location`.`name` AS `general_location_name`,`artefact`.`specific_location_id` AS `specific_location_id`,`specific_location`.`summary` AS `specific_location_summary`,`artefact`.`period_id` AS `period_id`,`period`.`dates` AS `period_dates` from ((((((`artefact` left join `identifier_group` on(`artefact`.`identifier_group_id` = `identifier_group`.`identifier_group_id`)) left join `category` on(`artefact`.`category_id` = `category`.`category_id`)) left join `creator` on(`artefact`.`creator_id` = `creator`.`creator_id`)) left join `general_location` on(`artefact`.`general_location_id` = `general_location`.`general_location_id`)) left join `specific_location` on(`artefact`.`specific_location_id` = `specific_location`.`specific_location_id`)) left join `period` on(`artefact`.`period_id` = `period`.`period_id`)) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-01-29 14:59:04


-- Setup script to create readonly user account. If the user already exists, no changes will be made to the user.

DELIMITER //

CREATE PROCEDURE CreateReadOnlyUser()
BEGIN
-- Check if user exists
    DECLARE user_exists INT DEFAULT 0;

    SELECT count(*)
    INTO user_exists
    FROM mysql.user
    WHERE user = 'readonly_user' AND host = 'localhost';

    -- Create user account only if user does not exist
    IF user_exists = 0 THEN
        CREATE USER 'readonly_user'@'localhost';
        GRANT SELECT ON margam_archives.* TO 'readonly_user'@'localhost';
        FLUSH PRIVILEGES;
    END IF;
END //

DELIMITER ;

